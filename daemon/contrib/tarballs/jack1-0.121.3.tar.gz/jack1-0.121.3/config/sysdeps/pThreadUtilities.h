#ifndef _jack_sysdep_pThreadUtilities_h_
#define _jack_sysdep_pThreadUtilities_h_

#if defined(__MACH__) && defined(__APPLE__)
#include <config/os/macosx/pThreadUtilities.h>
#endif

#endif /* _jack_sysdep_pThreadUtilities_h_ */
