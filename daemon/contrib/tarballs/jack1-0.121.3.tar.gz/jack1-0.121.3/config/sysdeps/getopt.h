#ifndef _jack_sysdep_getopt_h_
#define _jack_sysdep_getopt_h_

#if defined(__MACH__) && defined(__APPLE__)
#include <config/os/macosx/getopt.h>
#endif

#endif /* _jack_sysdep_getopt_h_ */
