#ifndef _jack_sysdep_mach_port_h_
#define _jack_sysdep_mach_port_h_

#if defined(__MACH__) && defined(__APPLE__)
#include <config/os/macosx/mach_port.h>
#endif

#endif /* _jack_sysdep_mach_port_h_ */
