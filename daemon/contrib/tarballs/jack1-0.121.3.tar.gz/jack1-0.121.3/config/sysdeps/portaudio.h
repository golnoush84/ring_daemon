#ifndef _jack_sysdep_portaudio_h_
#define _jack_sysdep_portaudio_h_

#if defined(__MACH__) && defined(__APPLE__)
#include <PortAudio.h>
#endif

#endif /* _jack_sysdep_portaudio_h_ */
