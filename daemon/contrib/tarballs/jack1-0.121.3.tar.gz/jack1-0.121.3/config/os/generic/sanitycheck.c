#include <jack/sanitycheck.h>

int
sanitycheck (int a, int b)
{
	return 0;
}
