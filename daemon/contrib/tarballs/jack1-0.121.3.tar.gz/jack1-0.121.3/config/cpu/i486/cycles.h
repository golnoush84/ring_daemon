/* the i386 version of this header is compatible */

#include <config/cpu/i386/cycles.h>
