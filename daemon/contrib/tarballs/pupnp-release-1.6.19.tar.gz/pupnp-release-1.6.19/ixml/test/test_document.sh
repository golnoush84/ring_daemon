#!/bin/sh

./test_document `find $srcdir/test/testdata -name *.xml`

