autoreconf --install --verbose -Wall
